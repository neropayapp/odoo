﻿# Neropay Payment Gateway for Odoo
Accept secure payments with Neropay inside Odoo.

## Features
- Sandbox and Live mode
- Automatic IPN handling
- Supported currencies: GBP, EUR, IDR

## Support
📧 support@neropay.app  
📞 +44 333 049 4380  
🏢 Stockport, UK
